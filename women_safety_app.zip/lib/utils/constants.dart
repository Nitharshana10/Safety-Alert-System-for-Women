import 'package:flutter/material.dart';

const Color primaryColor = Colors.blue;
