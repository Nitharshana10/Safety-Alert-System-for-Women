import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:women_safety_app/model/contact_model.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:women_safety_app/widgets/edit_contact_dialog.dart';
import 'package:women_safety_app/widgets/add_contact_dialog.dart';
import 'package:women_safety_app/db/share_pref.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  List<Contact> contacts = [];
  String userName = 'User';
  String userEmail = 'user@email.com';
  String userPhone = '+1 (555) 000-0000';
  List<Map<String, dynamic>> alertHistory = [];
  bool isListening = false;
  String detectedText = '';
  double currentVolume = 0.0;
  bool isHighPitch = false;
  Timer? safetyTimer;
  bool showSafeButton = false;
  int countdown = 10;
  bool showAlertPopup = false;
  String alertPopupMessage = '';
  String alertPopupType = '';
  double _maxDecibel = 0.0;
  final double _alertThreshold = 80.0;



  @override
  void initState() {
    super.initState();
    _loadContacts();
    _loadUserProfile();
    _loadAlertHistory();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _loadUserProfile() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userName = prefs.getString('user_name') ?? 'User';
      userEmail = prefs.getString('user_email') ?? 'user@email.com';
      userPhone = prefs.getString('user_phone') ?? '+1 (555) 000-0000';
    });
  }

  Future<void> _loadAlertHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyStrings = prefs.getStringList('alert_history') ?? [];
    setState(() {
      alertHistory = historyStrings.map((h) {
        final parts = h.split('|');
        return {
          'type': parts[0],
          'message': parts[1],
          'timestamp': DateTime.parse(parts[2]),
          'contactCount': int.parse(parts[3]),
        };
      }).toList();
    });
  }

  Future<void> _saveAlertToHistory(String type, String message) async {
    final alert = {
      'type': type,
      'message': message,
      'timestamp': DateTime.now(),
      'contactCount': contacts.length,
    };
    setState(() {
      alertHistory.insert(0, alert);
    });
    final prefs = await SharedPreferences.getInstance();
    final historyStrings = alertHistory.map((a) => 
      '${a['type']}|${a['message']}|${a['timestamp'].toIso8601String()}|${a['contactCount']}'
    ).toList();
    await prefs.setStringList('alert_history', historyStrings);
  }

  Future<void> _loadContacts() async {
    final loadedContacts = await MySharedPreference.getContacts();
    setState(() {
      contacts = loadedContacts;
      // Add default police contact if not exists
      if (!contacts.any((contact) => contact.phoneNumber == '112')) {
        contacts.insert(0, Contact(name: 'Emergency Police', phoneNumber: '112'));
      }
    });
  }

  Future<void> _saveContacts() async {
    await MySharedPreference.saveContacts(contacts);
  }

  void _showEditProfileDialog() {
    final nameController = TextEditingController(text: userName);
    final emailController = TextEditingController(text: userEmail);
    final phoneController = TextEditingController(text: userPhone);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Edit Profile',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(
                labelText: 'Phone',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.poppins()),
          ),
          ElevatedButton(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('user_name', nameController.text);
              await prefs.setString('user_email', emailController.text);
              await prefs.setString('user_phone', phoneController.text);
              setState(() {
                userName = nameController.text;
                userEmail = emailController.text;
                userPhone = phoneController.text;
              });
              Navigator.pop(context);
              _showAlertPopup('Profile updated successfully!', 'success');
            },
            child: Text('Save', style: GoogleFonts.poppins()),
          ),
        ],
      ),
    );
  }

  Future<Position?> _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return null;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return null;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return null;
    }
    return await Geolocator.getCurrentPosition();
  }

  void _showAlertPopup(String message, String type) {
    setState(() {
      showAlertPopup = true;
      alertPopupMessage = message;
      alertPopupType = type;
    });
    Timer(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          showAlertPopup = false;
        });
      }
    });
  }

  Future<void> _shareLocationWithContacts() async {
    final position = await _getCurrentLocation();
    if (position == null) {
      _showAlertPopup('Location permission denied', 'error');
      return;
    }
    final locationUrl = 'https://maps.google.com/?q=${position.latitude},${position.longitude}';
    for (final contact in contacts) {
      final smsUrl = Uri.parse('sms:${contact.phoneNumber}?body=My live location: $locationUrl');
      if (await canLaunchUrl(smsUrl)) {
        await launchUrl(smsUrl);
      }
    }
    _showAlertPopup('Location shared with all contacts', 'success');
  }





  void _triggerVoiceAlert() {
    setState(() {
      showSafeButton = true;
      countdown = 10;
      detectedText = 'High decibel detected: ${currentVolume.toStringAsFixed(1)} dB';
    });
    
    safetyTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        countdown--;
      });
      
      if (countdown <= 0) {
        timer.cancel();
        _sendVoiceAlert();
        setState(() {
          showSafeButton = false;
        });
      }
    });
  }

  Future<void> _sendVoiceAlert() async {
    final position = await _getCurrentLocation();
    String message = 'EMERGENCY VOICE ALERT! I need immediate help!';
    
    if (position != null) {
      final locationUrl = 'https://maps.google.com/?q=${position.latitude},${position.longitude}';
      message += ' My location: $locationUrl';
    }

    for (final contact in contacts) {
      final smsUrl = Uri.parse('sms:${contact.phoneNumber}?body=$message');
      if (await canLaunchUrl(smsUrl)) {
        await launchUrl(smsUrl);
      }
    }

    await _saveAlertToHistory('Voice Alert', 'High decibel detected - Emergency alert sent');
    _showAlertPopup('Voice alert sent to ${contacts.length} contacts!', 'success');
  }

  Future<void> _sendEmergencyMessage() async {
    const message = 'Emergency! I need help immediately!';
    for (final contact in contacts) {
      final smsUrl = Uri.parse('sms:${contact.phoneNumber}?body=$message');
      if (await canLaunchUrl(smsUrl)) {
        await launchUrl(smsUrl);
      }
    }
    _saveAlertToHistory('Message', message);
    _showAlertPopup('Emergency message sent!', 'message');
  }

  Widget _buildSOSPage() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.red,
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Text(
                'Women Safety App',
                style: GoogleFonts.poppins(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3),
                    width: 3,
                  ),
                ),
                child: const Icon(
                  Icons.warning_rounded,
                  size: 80,
                  color: Colors.white,
                ),
              ).animate(onPlay: (controller) => controller.repeat())
                  .scale(duration: 2000.ms, begin: const Offset(1, 1), end: const Offset(1.1, 1.1))
                  .then()
                  .scale(duration: 2000.ms, begin: const Offset(1.1, 1.1), end: const Offset(1, 1)),
              const SizedBox(height: 32),
              Text(
                'Emergency SOS',
                style: GoogleFonts.poppins(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Press and hold to send emergency alert',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: Colors.white.withOpacity(0.9),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 48),
              GestureDetector(
                onLongPress: () {
                  _shareLocationWithContacts();
                  _saveAlertToHistory('SOS', 'Emergency SOS alert with location');
                  _showAlertPopup('SOS sent to all contacts!', 'sos');
                },
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.red.shade800,
                    borderRadius: BorderRadius.circular(100),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'HOLD\nFOR\nSOS',
                      style: GoogleFonts.poppins(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Long press the button above',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
              const SizedBox(height: 40),
              // Safety Confirmation Dialog
              if (showSafeButton)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.yellow.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.orange, width: 2),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        Icons.warning_amber_rounded,
                        size: 40,
                        color: Colors.red[800],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'HIGH DECIBEL DETECTED!',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.red[800],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Alert will be sent in $countdown seconds',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          color: Colors.red[700],
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _cancelAlert,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          'I AM SAFE',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ).animate()
                  .scale(duration: 300.ms)
                  .shake(duration: 500.ms),
              // Voice Detection Widget
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          isListening ? Icons.mic : Icons.mic_off,
                          color: Colors.white,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          isListening ? 'Voice Detection ON' : 'Voice Detection OFF',
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (isListening) ...[
                      Text(
                        'Current: ${currentVolume.toStringAsFixed(1)} dB',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                      Text(
                        'Max: ${_maxDecibel.toStringAsFixed(1)} dB',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: (currentVolume / 100).clamp(0.0, 1.0),
                        backgroundColor: Colors.white.withOpacity(0.3),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          currentVolume > _alertThreshold ? Colors.red : Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Alert Threshold: ${_alertThreshold.toInt()} dB',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: Colors.white60,
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    Material(
                      color: Colors.transparent,
                      child: ElevatedButton(
                        onPressed: () {
                          print('SOS page button pressed');
                          _toggleVoiceDetection();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isListening ? Colors.orange : Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: Text(
                          isListening ? 'Stop Detection' : 'Start Detection',
                          style: GoogleFonts.poppins(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              // Emergency Message Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _sendEmergencyMessage,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[900],
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: const BorderSide(color: Colors.white, width: 2),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.message, size: 24),
                      const SizedBox(width: 8),
                      Text(
                        'Send Emergency Message',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessagePage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF4F46E5),
            Color(0xFF7C3AED),
          ],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Text(
                'Quick Messages',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Send pre-defined messages to your contacts',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: Colors.white.withOpacity(0.8),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  children: [
                    _buildMessageCard(
                      'Help Me',
                      Icons.help_outline,
                      'I need help!',
                      const Color(0xFFEF4444),
                    ),
                    _buildMessageCard(
                      'Safe',
                      Icons.check_circle_outline,
                      'I am safe now',
                      const Color(0xFF10B981),
                    ),
                    _buildMessageCard(
                      'Location',
                      Icons.location_on_outlined,
                      'Sharing my location',
                      const Color(0xFF3B82F6),
                    ),
                    _buildMessageCard(
                      'Call Me',
                      Icons.phone_outlined,
                      'Please call me urgently',
                      const Color(0xFFF59E0B),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }



  Widget _buildMessageCard(String title, IconData icon, String message, Color color) {
    return GestureDetector(
      onTap: () async {
        for (final contact in contacts) {
          final smsUrl = Uri.parse('sms:${contact.phoneNumber}?body=$message');
          if (await canLaunchUrl(smsUrl)) {
            await launchUrl(smsUrl);
          }
        }
        _saveAlertToHistory('Message', message);
        _showAlertPopup('"$message" sent to all contacts!', 'message');
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(
                icon,
                size: 32,
                color: color,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              message,
              style: GoogleFonts.poppins(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    ).animate().scale(delay: (100).ms, duration: 300.ms);
  }

  void _toggleVoiceDetection() {
    print('Toggle voice detection called. Current state: $isListening');
    setState(() {
      isListening = !isListening;
    });
    
    if (isListening) {
      _showAlertPopup('Voice detection started', 'success');
      // Simulate voice detection for demo
      Timer(const Duration(seconds: 3), () {
        if (isListening && !showSafeButton) {
          setState(() {
            currentVolume = 85.0; // Simulate high decibel above threshold
            _maxDecibel = 85.0;
          });
          _triggerVoiceAlert();
        }
      });
    } else {
      _showAlertPopup('Voice detection stopped', 'success');
      setState(() {
        currentVolume = 0.0;
        _maxDecibel = 0.0;
      });
    }
  }

  void _cancelAlert() {
    safetyTimer?.cancel();
    setState(() {
      showSafeButton = false;
      detectedText = '';
      countdown = 10;
    });
    _showAlertPopup('Alert cancelled - I am safe', 'success');
  }



  Widget _buildVoicePage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF059669),
            Color(0xFF10B981),
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Text(
                    'Voice Guardian',
                    style: GoogleFonts.poppins(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'AI-powered voice detection',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.white.withOpacity(0.8),
                    ),
                  ),
                ],
              ),
            ),
            // Voice Detection Section
            Expanded(
              flex: 2,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          print('Voice page button pressed');
                          _toggleVoiceDetection();
                        },
                        borderRadius: BorderRadius.circular(75),
                        child: Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                            color: isListening 
                                ? Colors.red.withOpacity(0.2)
                                : Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(75),
                            border: Border.all(
                              color: isListening 
                                  ? Colors.red.withOpacity(0.5)
                                  : Colors.white.withOpacity(0.3),
                              width: 3,
                            ),
                          ),
                          child: Icon(
                            isListening ? Icons.stop : Icons.mic,
                            size: 60,
                            color: Colors.white,
                          ),
                        ).animate(
                          target: isListening ? 1 : 0,
                        ).scale(
                          begin: const Offset(1, 1),
                          end: const Offset(1.1, 1.1),
                          duration: 1000.ms,
                        ).then().scale(
                          begin: const Offset(1.1, 1.1),
                          end: const Offset(1, 1),
                          duration: 1000.ms,
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      isListening ? 'Listening...' : 'Tap to Start',
                      style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                    if (isListening)
                      const SizedBox(height: 16),
                    if (isListening)
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          children: [
                            Text(
                              'Volume: ${(currentVolume * 100).toInt()}%',
                              style: GoogleFonts.poppins(
                                fontSize: 14,
                                color: Colors.white.withOpacity(0.9),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              height: 6,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.3),
                                borderRadius: BorderRadius.circular(3),
                              ),
                              child: FractionallySizedBox(
                                alignment: Alignment.centerLeft,
                                widthFactor: currentVolume,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: currentVolume > 0.7 ? Colors.red : Colors.white,
                                    borderRadius: BorderRadius.circular(3),
                                  ),
                                ),
                              ),
                            ),
                            if (isHighPitch)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(
                                  'High Pitch Detected',
                                  style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    color: Colors.red.shade200,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    if (detectedText.isNotEmpty)
                      const SizedBox(height: 16),
                    if (showSafeButton)
                      Container(
                        padding: const EdgeInsets.all(20),
                        margin: const EdgeInsets.symmetric(horizontal: 24),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.red.withOpacity(0.4),
                            width: 2,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              'Emergency Detected!',
                              style: GoogleFonts.poppins(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              detectedText,
                              style: GoogleFonts.poppins(
                                fontSize: 14,
                                color: Colors.white.withOpacity(0.9),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'Alert sending in $countdown seconds',
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                minimumSize: const Size(200, 50),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(25),
                                ),
                              ),
                              onPressed: _cancelAlert,
                              child: Text(
                                'I AM SAFE',
                                style: GoogleFonts.poppins(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                  ],
                ),
              ),
            ),
            // Recent Voice Alerts History
            Expanded(
              flex: 1,
              child: Container(
                margin: const EdgeInsets.only(top: 16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(32),
                    topRight: Radius.circular(32),
                  ),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        'Recent Voice Alerts',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey.shade800,
                        ),
                      ),
                    ),
                    Expanded(
                      child: alertHistory.where((alert) => alert['type'] == 'Voice').isEmpty
                          ? Center(
                              child: Text(
                                'No voice alerts yet',
                                style: GoogleFonts.poppins(
                                  fontSize: 16,
                                  color: Colors.grey.shade500,
                                ),
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              itemCount: alertHistory.where((alert) => alert['type'] == 'Voice').length,
                              itemBuilder: (context, index) {
                                final voiceAlerts = alertHistory.where((alert) => alert['type'] == 'Voice').toList();
                                final alert = voiceAlerts[index];
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 8),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.green.shade50,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.green.shade200,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: Colors.green.shade100,
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Icon(
                                          Icons.mic,
                                          size: 16,
                                          color: Colors.green.shade700,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Voice Alert',
                                              style: GoogleFonts.poppins(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.grey.shade800,
                                              ),
                                            ),
                                            Text(
                                              '${alert['timestamp'].hour.toString().padLeft(2, '0')}:${alert['timestamp'].minute.toString().padLeft(2, '0')}',
                                              style: GoogleFonts.poppins(
                                                fontSize: 12,
                                                color: Colors.grey.shade600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactsPage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF8B5CF6),
            Color(0xFFEC4899),
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Profile & Header Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Profile Card
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Icon(
                            Icons.person,
                            size: 32,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                userName,
                                style: GoogleFonts.poppins(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                userEmail,
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  color: Colors.white.withOpacity(0.8),
                                ),
                              ),
                              Text(
                                userPhone,
                                style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  color: Colors.white.withOpacity(0.8),
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _showEditProfileDialog(),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.edit_outlined,
                              size: 20,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Emergency Contacts',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Manage your trusted contacts',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.white.withOpacity(0.8),
                    ),
                  ),
                ],
              ),
            ),
            // Contacts List
            Expanded(
              child: Container(
                margin: const EdgeInsets.only(top: 16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(32),
                    topRight: Radius.circular(32),
                  ),
                ),
                child: contacts.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(24),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Icon(
                                Icons.person_add_outlined,
                                size: 64,
                                color: Colors.grey.shade400,
                              ),
                            ),
                            const SizedBox(height: 24),
                            Text(
                              'No contacts added yet',
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey.shade700,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Add trusted contacts for emergency situations',
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                color: Colors.grey.shade500,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(24),
                        itemCount: contacts.length,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: const EdgeInsets.only(bottom: 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(16),
                              leading: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: contacts[index].phoneNumber == '112'
                                      ? const LinearGradient(
                                          colors: [Color(0xFFEF4444), Color(0xFFDC2626)],
                                        )
                                      : const LinearGradient(
                                          colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
                                        ),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Icon(
                                  contacts[index].phoneNumber == '112'
                                      ? Icons.local_police
                                      : Icons.person,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                              title: Text(
                                contacts[index].name,
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              subtitle: Text(
                                contacts[index].phoneNumber,
                                style: GoogleFonts.poppins(
                                  color: Colors.grey.shade600,
                                ),
                              ),
                              trailing: contacts[index].phoneNumber == '112'
                                  ? Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFEF4444).withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                          color: const Color(0xFFEF4444).withOpacity(0.3),
                                        ),
                                      ),
                                      child: Text(
                                        'DEFAULT',
                                        style: GoogleFonts.poppins(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w600,
                                          color: const Color(0xFFEF4444),
                                        ),
                                      ),
                                    )
                                  : Container(
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade100,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: IconButton(
                                        icon: const Icon(Icons.edit_outlined),
                                        color: Colors.grey.shade600,
                                        onPressed: () {
                                          showDialog(
                                            context: context,
                                            builder: (context) => EditContactDialog(
                                              contact: contacts[index],
                                              onSave: (updatedContact) {
                                                setState(() {
                                                  contacts[index] = updatedContact;
                                                });
                                                _saveContacts();
                                              },
                                              onDelete: () {
                                                setState(() {
                                                  contacts.removeAt(index);
                                                });
                                                _saveContacts();
                                                Navigator.pop(context);
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                            ),
                          ).animate().slideX(delay: (index * 100).ms, duration: 300.ms);
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryPage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1F2937),
            Color(0xFF374151),
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 2,
                      ),
                    ),
                    child: const Icon(
                      Icons.history_rounded,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Alert History',
                    style: GoogleFonts.poppins(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Track your sent alerts',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.white.withOpacity(0.8),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                margin: const EdgeInsets.only(top: 16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(32),
                    topRight: Radius.circular(32),
                  ),
                ),
                child: alertHistory.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(24),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Icon(
                                Icons.history_outlined,
                                size: 64,
                                color: Colors.grey.shade400,
                              ),
                            ),
                            const SizedBox(height: 24),
                            Text(
                              'No alerts sent yet',
                              style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey.shade700,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Your alert history will appear here',
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                color: Colors.grey.shade500,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(24),
                        itemCount: alertHistory.length,
                        itemBuilder: (context, index) {
                          final alert = alertHistory[index];
                          final isToday = DateTime.now().difference(alert['timestamp']).inDays == 0;
                          return Container(
                            margin: const EdgeInsets.only(bottom: 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(16),
                              leading: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: alert['type'] == 'SOS'
                                        ? [const Color(0xFFEF4444), const Color(0xFFDC2626)]
                                        : [const Color(0xFF3B82F6), const Color(0xFF1D4ED8)],
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Icon(
                                  alert['type'] == 'SOS' ? Icons.warning : Icons.message,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                              title: Text(
                                alert['message'],
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                ),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 4),
                                  Text(
                                    'Sent to ${alert['contactCount']} contacts',
                                    style: GoogleFonts.poppins(
                                      color: Colors.grey.shade600,
                                      fontSize: 14,
                                    ),
                                  ),
                                  Text(
                                    isToday
                                        ? 'Today ${alert['timestamp'].hour.toString().padLeft(2, '0')}:${alert['timestamp'].minute.toString().padLeft(2, '0')}'
                                        : '${alert['timestamp'].day}/${alert['timestamp'].month}/${alert['timestamp'].year}',
                                    style: GoogleFonts.poppins(
                                      color: Colors.grey.shade500,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                              trailing: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: alert['type'] == 'SOS'
                                      ? const Color(0xFFEF4444).withOpacity(0.1)
                                      : const Color(0xFF3B82F6).withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  alert['type'],
                                  style: GoogleFonts.poppins(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: alert['type'] == 'SOS'
                                        ? const Color(0xFFEF4444)
                                        : const Color(0xFF3B82F6),
                                  ),
                                ),
                              ),
                            ),
                          ).animate().slideX(delay: (index * 100).ms, duration: 300.ms);
                        },
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _pages() => [
    _buildSOSPage(),
    _buildMessagePage(),
    _buildVoicePage(),
    _buildContactsPage(),
    _buildHistoryPage(),
  ];

  Widget _buildAlertPopup() {
    if (!showAlertPopup) return const SizedBox.shrink();
    
    Color bgColor;
    IconData icon;
    switch (alertPopupType) {
      case 'sos':
        bgColor = const Color(0xFFFF6B6B);
        icon = Icons.warning;
        break;
      case 'emergency':
        bgColor = Colors.red.shade600;
        icon = Icons.warning;
        break;
      case 'message':
        bgColor = const Color(0xFF4F46E5);
        icon = Icons.message;
        break;
      case 'success':
        bgColor = Colors.green.shade600;
        icon = Icons.check_circle;
        break;
      case 'error':
        bgColor = Colors.orange.shade600;
        icon = Icons.error;
        break;
      default:
        bgColor = Colors.blue.shade600;
        icon = Icons.info;
    }
    
    return Positioned(
      top: 60,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                alertPopupMessage,
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ),
            GestureDetector(
              onTap: () => setState(() => showAlertPopup = false),
              child: const Icon(Icons.close, color: Colors.white, size: 20),
            ),
          ],
        ),
      ).animate().slideY(begin: -1, duration: 300.ms).fadeIn(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          _pages()[_selectedIndex],
          _buildAlertPopup(),
        ],
      ),
      floatingActionButton: _selectedIndex == 3
          ? Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF8B5CF6), Color(0xFFEC4899)],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF8B5CF6).withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: FloatingActionButton(
                backgroundColor: Colors.transparent,
                elevation: 0,
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AddContactDialog(
                      onAdd: (newContact) {
                        setState(() {
                          contacts.add(newContact);
                        });
                        _saveContacts();
                      },
                    ),
                  );
                },
                child: const Icon(Icons.add, color: Colors.white),
              ),
            )
          : _selectedIndex == 4
              ? Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF374151), Color(0xFF1F2937)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF374151).withOpacity(0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: FloatingActionButton(
                    backgroundColor: Colors.transparent,
                    elevation: 0,
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.remove('alert_history');
                      setState(() {
                        alertHistory.clear();
                      });
                      _showAlertPopup('History cleared!', 'success');
                    },
                    child: const Icon(Icons.clear_all, color: Colors.white),
                  ),
                )
              : null,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xFF6366F1),
            unselectedItemColor: Colors.grey.shade400,
            showUnselectedLabels: true,
            type: BottomNavigationBarType.fixed,
            backgroundColor: Colors.white,
            elevation: 0,
            selectedLabelStyle: GoogleFonts.poppins(
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
            unselectedLabelStyle: GoogleFonts.poppins(
              fontSize: 12,
            ),
            onTap: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            items: [
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _selectedIndex == 0 
                        ? const Color(0xFFFF6B6B).withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.warning_rounded,
                    color: _selectedIndex == 0 
                        ? const Color(0xFFFF6B6B)
                        : Colors.grey.shade400,
                  ),
                ),
                label: 'SOS',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _selectedIndex == 1 
                        ? const Color(0xFF4F46E5).withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.message_rounded,
                    color: _selectedIndex == 1 
                        ? const Color(0xFF4F46E5)
                        : Colors.grey.shade400,
                  ),
                ),
                label: 'Messages',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _selectedIndex == 2 
                        ? const Color(0xFF059669).withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.mic_rounded,
                    color: _selectedIndex == 2 
                        ? const Color(0xFF059669)
                        : Colors.grey.shade400,
                  ),
                ),
                label: 'Voice',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _selectedIndex == 3 
                        ? const Color(0xFF8B5CF6).withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.contacts_rounded,
                    color: _selectedIndex == 3 
                        ? const Color(0xFF8B5CF6)
                        : Colors.grey.shade400,
                  ),
                ),
                label: 'Contacts',
              ),
              BottomNavigationBarItem(
                icon: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _selectedIndex == 4 
                        ? const Color(0xFF374151).withOpacity(0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.history_rounded,
                    color: _selectedIndex == 4 
                        ? const Color(0xFF374151)
                        : Colors.grey.shade400,
                  ),
                ),
                label: 'History',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
