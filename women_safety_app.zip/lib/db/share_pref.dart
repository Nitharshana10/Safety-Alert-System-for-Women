	import 'package:shared_preferences/shared_preferences.dart';
	import 'package:women_safety_app/model/contact_model.dart';

	class MySharedPreference {
		static const String _keyUsers = 'users';
		static const String _keyContacts = 'contacts';

		// Save contacts
		static Future<void> saveContacts(List<Contact> contacts) async {
			final prefs = await SharedPreferences.getInstance();
			final contactStrings = contacts.map((c) => '${c.name}|${c.phoneNumber}').toList();
			await prefs.setStringList(_keyContacts, contactStrings);
		}

		// Get contacts
		static Future<List<Contact>> getContacts() async {
			final prefs = await SharedPreferences.getInstance();
			final contactStrings = prefs.getStringList(_keyContacts) ?? [];
			return contactStrings.map((s) {
				final parts = s.split('|');
				return Contact(name: parts[0], phoneNumber: parts[1]);
			}).toList();
		}

		// Save user with email as unique key
		static Future<void> saveUser({
			required String name,
			required String email,
			required String password,
			required String phone,
		}) async {
			final prefs = await SharedPreferences.getInstance();
			final users = prefs.getStringList(_keyUsers) ?? [];
			// Remove any existing user with same email
			final filtered = users.where((u) => !u.startsWith('$email|')).toList();
			filtered.add('$email|$password|$name|$phone');
			await prefs.setStringList(_keyUsers, filtered);
			// Also save current user profile
			await prefs.setString('user_name', name);
			await prefs.setString('user_email', email);
			await prefs.setString('user_phone', phone);
		}

		// Validate user by email and password
		static Future<bool> validateUser(String email, String password) async {
			final prefs = await SharedPreferences.getInstance();
			final users = prefs.getStringList(_keyUsers) ?? [];
			for (final user in users) {
				final parts = user.split('|');
				if (parts.length == 4 && parts[0] == email && parts[1] == password) {
					// Load user profile on successful login
					await prefs.setString('user_name', parts[2]);
					await prefs.setString('user_email', parts[0]);
					await prefs.setString('user_phone', parts[3]);
					return true;
				}
			}
			return false;
		}

		// Get user details by email
		static Future<Map<String, String>?> getUser(String email) async {
			final prefs = await SharedPreferences.getInstance();
			final users = prefs.getStringList(_keyUsers) ?? [];
			for (final user in users) {
				final parts = user.split('|');
				if (parts.length == 4 && parts[0] == email) {
					return {
						'email': parts[0],
						'password': parts[1],
						'name': parts[2],
						'phone': parts[3],
					};
				}
			}
			return null;
		}
	}
