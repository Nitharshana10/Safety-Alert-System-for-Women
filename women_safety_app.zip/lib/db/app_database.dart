import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:women_safety_app/model/contact_model.dart';

class AppDatabase {
  static Database? _db;

  static Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  static Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'women_safety.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT,
            phone TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            phoneNumber TEXT
          )
        ''');
      },
    );
  }

  // User methods
  static Future<int> insertUser({
    required String name,
    required String email,
    required String password,
    required String phone,
  }) async {
    final db = await database;
    return await db.insert('users', {
      'name': name,
      'email': email,
      'password': password,
      'phone': phone,
    });
  }

  static Future<Map<String, dynamic>?> getUser(String email) async {
    final db = await database;
    final result = await db.query('users', where: 'email = ?', whereArgs: [email]);
    if (result.isNotEmpty) return result.first;
    return null;
  }

  static Future<bool> validateUser(String email, String password) async {
    final db = await database;
    final result = await db.query('users', where: 'email = ? AND password = ?', whereArgs: [email, password]);
    return result.isNotEmpty;
  }

  // Contact methods
  static Future<int> insertContact(Contact contact) async {
    final db = await database;
    return await db.insert('contacts', {
      'name': contact.name,
      'phoneNumber': contact.phoneNumber,
    });
  }

  static Future<List<Contact>> getContacts() async {
    final db = await database;
    final result = await db.query('contacts');
    return result.map((row) => Contact(name: row['name'] as String, phoneNumber: row['phoneNumber'] as String)).toList();
  }

  static Future<int> updateContact(int id, Contact contact) async {
    final db = await database;
    return await db.update('contacts', {
      'name': contact.name,
      'phoneNumber': contact.phoneNumber,
    }, where: 'id = ?', whereArgs: [id]);
  }

  static Future<int> deleteContact(int id) async {
    final db = await database;
    return await db.delete('contacts', where: 'id = ?', whereArgs: [id]);
  }
}
